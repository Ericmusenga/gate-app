<?php
session_start();

// Database connection
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'gate';

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $inputPassword = $_POST['password'];
    $user_type = strtolower($_POST['user_type']); // normalize casing

    $query = "SELECT * FROM users WHERE email=? AND user_type=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $email, $user_type);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        if (password_verify($inputPassword, $row['password'])) {
            $_SESSION['user'] = $row;

            // Redirect user based on role
            switch ($user_type) {
                case 'admin':
                    header("Location: admin_dashboard.php");
                    break;
                case 'standard':
                    header("Location: standard_dashboard.php");
                    break;
                default:
                    header("Location: dashboard.php");
                    break;
            }
            exit();
        } else {
            echo "❌ Incorrect password.";
        }
    } else {
        echo "❌ Invalid email or user type.";
    }
}
?>
